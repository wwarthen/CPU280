ZX Command

An adaptation of zxcc-0.5.6 by Wayne Warthen
December 5, 2014

This directory contains the source files used to build the "zx" tool.  This tool
is essentially just John Elliott's zxcc package version zxcc-0.5.6 modified to
build under Microsoft Visual C and simplified down to just a single command (zx)
which is essentially just the zxcc command.

After struggling to get the entire zxcc package to build nicely using autoconf,
I finally gave up and took a much more direct approach.  I have extracted just
the source files needed and created a simple batch file to build the tool.  I
realize this could be done much better, but I cheated in the interest of time.

The one "real" change I made in the source code was that I modified the tool
to look for bios.bin in the same directory as the executable is in.  This
just makes it much easier to set up (for me, anyway).

The GPL status of everything remains in place and carries forward.

Wayne Warthen
wwarthen@gmail.com